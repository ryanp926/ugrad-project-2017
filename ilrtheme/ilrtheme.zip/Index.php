<?php get_header(); ?>
     --><div id="hero_with_bg" class="fr-widget fr-container fr_hero_with_bg">
            <div id="hd3_content" class="fr-widget fr-container fr_hd3_content">
                <div id="text_25" class="fr-widget fr-text fr-wf fr_text_bright_left fr_text_25">
                    <div class="fr-text">
                        <h1>All things Reno</h1>
                        <p>Everything you need to know going on within your community.</p>
                    </div>
                </div>
            </div><!--
         --><div id="input_5" class="fr-widget fr-input fr-wf fr_input_5"> <input type="text" class="fr_input_5" placeholder="Search..." name="FNAME">
            </div>
        </div><!--
     --><div id="gallery_3" class="fr-widget fr-container fr_gallery_3">
            <div id="text_49" class="fr-widget fr-text fr-wf fr_text_dark_center fr_text_49">
                <div class="fr-text">
                    <h3>Keep yourself in the loop</h3>
                    <p> </p>
                </div>
            </div><!--
         --><div id="gry3_3_column_images" class="fr-widget fr-grid fr_gry3_3_column_images">
                <div id="gry3_image_one" class="fr-widget fr-container fr_gry3_image_one">
                    <div id="calendar_check_outlined_icon" class="fr-widget fr-svg fr_calendar_check_outlined_icon">
                        <div class="fr-svg-inner">
                            <svg width="1664" height="1792" viewBox="0 0 1664 1792" xmlns="http://www.w3.org/2000/svg"><path d="M1303 964l-512 512q-10 9-23 9t-23-9l-288-288q-9-10-9-23t9-22l46-46q9-9 22-9t23 9l220 220 444-444q10-9 23-9t22 9l46 46q9 9 9 22t-9 23zm-1175 700h1408v-1024h-1408v1024zm384-1216v-288q0-14-9-23t-23-9h-64q-14 0-23 9t-9 23v288q0 14 9 23t23 9h64q14 0 23-9t9-23zm768 0v-288q0-14-9-23t-23-9h-64q-14 0-23 9t-9 23v288q0 14 9 23t23 9h64q14 0 23-9t9-23zm384-64v1280q0 52-38 90t-90 38h-1408q-52 0-90-38t-38-90v-1280q0-52 38-90t90-38h128v-96q0-66 47-113t113-47h64q66 0 113 47t47 113v96h384v-96q0-66 47-113t113-47h64q66 0 113 47t47 113v96h128q52 0 90 38t38 90z"></path></svg>
                        </div>
                    </div><!--
                 --><div id="text_50" class="fr-widget fr-text fr-wf fr_text_50">
                        <div class="fr-text">
                            <p>Stay up to date with upcoming events. Set reminders to plan ahead of time.&nbsp;</p>
                        </div>
                    </div>
                </div><!--
             --><div id="gry3_image_two" class="fr-widget fr-container fr_gry3_image_two">
                    <div id="users_icon" class="fr-widget fr-svg fr_users_icon">
                        <div class="fr-svg-inner">
                            <svg width="1920" height="1792" viewBox="-64 0 1920 1792" xmlns="http://www.w3.org/2000/svg"><path d="M529 896q-162 5-265 128h-134q-82 0-138-40.5t-56-118.5q0-353 124-353 6 0 43.5 21t97.5 42.5 119 21.5q67 0 133-23-5 37-5 66 0 139 81 256zm1071 637q0 120-73 189.5t-194 69.5h-874q-121 0-194-69.5t-73-189.5q0-53 3.5-103.5t14-109 26.5-108.5 43-97.5 62-81 85.5-53.5 111.5-20q10 0 43 21.5t73 48 107 48 135 21.5 135-21.5 107-48 73-48 43-21.5q61 0 111.5 20t85.5 53.5 62 81 43 97.5 26.5 108.5 14 109 3.5 103.5zm-1024-1277q0 106-75 181t-181 75-181-75-75-181 75-181 181-75 181 75 75 181zm704 384q0 159-112.5 271.5t-271.5 112.5-271.5-112.5-112.5-271.5 112.5-271.5 271.5-112.5 271.5 112.5 112.5 271.5zm576 225q0 78-56 118.5t-138 40.5h-134q-103-123-265-128 81-117 81-256 0-29-5-66 66 23 133 23 59 0 119-21.5t97.5-42.5 43.5-21q124 0 124 353zm-128-609q0 106-75 181t-181 75-181-75-75-181 75-181 181-75 181 75 75 181z"></path></svg>
                        </div>
                    </div><!--
                 --><div id="text_51" class="fr-widget fr-text fr-wf fr_text_51">
                        <div class="fr-text">
                            <p>Engage with your local community. Share, explore, and receive feedback from others.</p>
                        </div>
                    </div>
                </div><!--
             --><div id="gry3_image_three" class="fr-widget fr-container fr_gry3_image_three">
                    <div id="newspaper_outlined_icon" class="fr-widget fr-svg fr_newspaper_outlined_icon">
                        <div class="fr-svg-inner">
                            <svg width="2048" height="1408" viewBox="-128 128 2048 1408" xmlns="http://www.w3.org/2000/svg"><path d="M896 512h-384v384h384v-384zm128 640v128h-640v-128h640zm0-768v640h-640v-640h640zm640 768v128h-512v-128h512zm0-256v128h-512v-128h512zm0-256v128h-512v-128h512zm0-256v128h-512v-128h512zm-1536 960v-960h-128v960q0 26 19 45t45 19 45-19 19-45zm1664 0v-1088h-1536v1088q0 33-11 64h1483q26 0 45-19t19-45zm128-1216v1216q0 80-56 136t-136 56h-1664q-80 0-136-56t-56-136v-1088h256v-128h1792z"></path></svg>
                        </div>
                    </div><!--
                 --><div id="text_52" class="fr-widget fr-text fr-wf fr_text_52">
                        <div class="fr-text">
                            <p>Find new and exciting locations near you with a&nbsp;personalized newsletter.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div><!--
     --><div id="gallery_5" class="fr-widget fr-container fr_gallery_5">
            <div id="gry2_column_images" class="fr-widget fr-grid fr_gry2_column_images">
                <div id="gry2_image_one" class="fr-widget fr-container fr_gry2_image_one fr-widget-hover-opacity-60">
                </div><!--
             --><div id="gry2_image_two" class="fr-widget fr-container fr_gry2_image_two fr-widget-hover-opacity-60">
                </div><!--
             --><div id="gry2_image_three" class="fr-widget fr-container fr_gry2_image_three fr-widget-hover-opacity-60">
                </div><!--
             --><div id="gry2_image_four" class="fr-widget fr-container fr_gry2_image_four fr-widget-hover-opacity-60">
                </div><!--
             --><div id="gry2_image_five" class="fr-widget fr-container fr_gry2_image_five fr-widget-hover-opacity-60">
                </div><!--
             --><div id="gry2_image_six" class="fr-widget fr-container fr_gry2_image_six fr-widget-hover-opacity-60">
                </div><!--
             --><div id="gry2_image_seven" class="fr-widget fr-container fr_gry2_image_seven fr-widget-hover-opacity-60">
                </div><!--
             --><div id="gry2_image_eight" class="fr-widget fr-container fr_gry2_image_eight fr-widget-hover-opacity-60">
                </div>
            </div>
        </div>
    <?php if ( have_posts() ) : ?>
    <?php while ( have_posts() ) : the_post(); ?>
      <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
        <div class="post-header">
           <div class="date"><?php the_time( 'M j y' ); ?></div>
           <h2><a href="<?php the_permalink(); ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
           <div class="author"><?php the_author(); ?></div>
        </div><!--end post header-->
        <div class="entry clear">
           <?php if ( function_exists( 'add_theme_support' ) ) the_post_thumbnail(); ?>
           <?php the_content(); ?>
           <?php edit_post_link(); ?>
           <?php wp_link_pages(); ?> </div>
        <!--end entry-->
        <div class="post-footer">
           <div class="comments"><?php comments_popup_link( 'Leave a Comment', '1 Comment', '% Comments' ); ?></div>
        </div><!--end post footer-->
        </div><!--end post-->
    <?php endwhile; /* rewind or continue if all posts have been fetched */ ?>
        <div class="navigation index">
           <div class="alignleft"><?php next_posts_link( 'Older Entries' ); ?></div>
           <div class="alignright"><?php previous_posts_link( 'Newer Entries' ); ?></div>
        </div><!--end navigation-->
    <?php else : ?>
    <?php endif; ?>
<?php get_footer(); ?>
