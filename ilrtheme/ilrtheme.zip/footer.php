    --><div id="footer_3" class="fr-widget fr-container fr_footer_3">
            <div id="f3_4_column_grid" class="fr-widget fr-grid fr_f3_4_column_grid">
                <a id="text_69" class="fr-widget fr-text fr-wf fr_text_69 fr-link" href="http://www.facebook.com/froontapp" target="_blank">
                    <div class="fr-text">Facebook</div>
                </a><!--
             --><a id="text_70" class="fr-widget fr-text fr-wf fr_text_70 fr-link" href="http://www.twitter.com/froontapp" target="_blank">
                    <div class="fr-text">Twitter</div>
                </a><!--
             --><a id="text_71" class="fr-widget fr-text fr-wf fr_text_71 fr-link" href="https://dribbble.com/froont" target="_blank">
                    <div class="fr-text">Instagram</div>
                </a>
            </div><!--
         --><div id="text_73" class="fr-widget fr-text fr-wf fr_text_dark_center fr_text_73">
                <div class="fr-text">
                    <p>Copyright © 2017&nbsp;I Love Reno</p>
                </div>
            </div>
        </div>
    </div>
    <div id="footer-assets">
    </div>
</body>

</html>